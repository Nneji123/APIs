---
title: Faster Rcnn
emoji: 💩
colorFrom: indigo
colorTo: gray
sdk: gradio
sdk_version: 2.8.13
app_file: app.py
pinned: false
---

Check out the configuration reference at https://huggingface.co/docs/hub/spaces#reference
