---
title: Cartoonizer Demo ONNX
emoji: 🗻
colorFrom: green
colorTo: gray
sdk: gradio
sdk_version: 3.1.4
app_file: app.py
pinned: false
license: apache-2.0
---

Check out the configuration reference at https://huggingface.co/docs/hub/spaces-config-reference
